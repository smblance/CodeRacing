from model.Car import Car
from model.Game import Game
from model.Move import Move
from model.World import World
from math import sin, cos, sqrt, pi

from convenience import adj_tile, distance
from path_to_waypoint import path_to_waypoint
from map_path import shortest_path_between_tiles

left, right, top, bot = (-1,0), (1,0), (0,-1), (0,1)
type_exits = {
    0 : [],
    1 : [top, bot],
    2 : [left, right],
    3 : [right, bot],
    4 : [left, bot],
    5 : [right, top],
    6 : [left, top],
    7 : [left, top, bot],
    8 : [right, top, bot],
    9 : [left, right, top],
    10 : [left, right, bot],
    11 : [left, right, top, bot],
    12 : [left, right, top, bot]
}

def get_target(me, world, cur_tile, next_tile, tile_size):
    if cur_tile[0] == next_tile[0]:
        return ( (cur_tile[0] + 1/2.)*tile_size, ((cur_tile[1] + next_tile[1])/2 + 1/2.)*tile_size)
    elif cur_tile[1] == next_tile[1]:
        return ( ((cur_tile[0] + next_tile[0])/2 + 1/2.)*tile_size, ((cur_tile[1])+ 1/2.)*tile_size)


class MyStrategy:

    def __init__(self):
        self.distance_to_waypoint = None
        self.map_path = None
        self.path = None

    def move(self, me, world, game, move):

        """
        @type me: Car
        @type world: World
        @type game: Game
        @type move: Move
        """

        
        
        #calculate variables
        tile_x = int(me.x/game.track_tile_size)  #round down
        tile_y = int(me.y/game.track_tile_size)  #round down
        cur_tile = (tile_x, tile_y)
        waypoint = (me.next_waypoint_x,me.next_waypoint_y)
        print cur_tile, waypoint
        path = path_to_waypoint(cur_tile, waypoint, world.tiles_x_y)
        next_tile = path[1]

        # move
        move.engine_power = 0.3
        target = get_target(me, world, cur_tile, next_tile, game.track_tile_size)
        angle_to_target = me.get_angle_to(target[0], target[1])
        move.wheel_turn = angle_to_target/pi

        if world.tick % 30 == 0:
            print (me.x,me.y), angle_to_target, target, move.wheel_turn

        move.throw_projectile = False
        move.spill_oil = False
        if world.tick > game.initial_freeze_duration_ticks:
            move.use_nitro = False
